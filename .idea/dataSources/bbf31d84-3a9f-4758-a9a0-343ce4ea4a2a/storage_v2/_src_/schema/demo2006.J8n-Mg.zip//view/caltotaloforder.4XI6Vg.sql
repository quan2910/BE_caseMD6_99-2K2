create definer = root@localhost view caltotaloforder as
select `demo2006`.`order`.`id` AS `id`, sum((`p`.`price` * `o`.`quantity`)) AS `Total`
from ((`demo2006`.`order` join `demo2006`.`orderdetail` `o`
       on ((`demo2006`.`order`.`id` = `o`.`orderId`))) join `demo2006`.`product` `p` on ((`p`.`id` = `o`.`productId`)))
group by `demo2006`.`order`.`id`;

